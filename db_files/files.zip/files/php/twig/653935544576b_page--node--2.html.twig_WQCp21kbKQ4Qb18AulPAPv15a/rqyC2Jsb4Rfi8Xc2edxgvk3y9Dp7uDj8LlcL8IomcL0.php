<?php

use Twig\Environment;
use Twig\Error\LoaderError;
use Twig\Error\RuntimeError;
use Twig\Extension\SandboxExtension;
use Twig\Markup;
use Twig\Sandbox\SecurityError;
use Twig\Sandbox\SecurityNotAllowedTagError;
use Twig\Sandbox\SecurityNotAllowedFilterError;
use Twig\Sandbox\SecurityNotAllowedFunctionError;
use Twig\Source;
use Twig\Template;

/* themes/custom/theme_dr_mario/templates/page--node--2.html.twig */
class __TwigTemplate_12a0d69d77afac3c5f7c1bd32b136a2b extends Template
{
    private $source;
    private $macros = [];

    public function __construct(Environment $env)
    {
        parent::__construct($env);

        $this->source = $this->getSourceContext();

        $this->parent = false;

        $this->blocks = [
        ];
        $this->sandbox = $this->env->getExtension('\Twig\Extension\SandboxExtension');
        $this->checkSecurity();
    }

    protected function doDisplay(array $context, array $blocks = [])
    {
        $macros = $this->macros;
        // line 1
        echo "<header class=\"header\">
  <nav>
    <div class=\"logo-wrapper\">
      <a><img class=\"logo\" src=\"/themes/custom/theme_dr_mario/assets/img/mario-arcila-logo.png\" alt=\"logo\"></a>
    </div>
    <div class=\"burger-menu\">
      <span></span>
      <span></span>
      <span></span>
    </div>
    <ul class=\"menu-container\">
      <li><a href=\"\">INICIO</a></li>
      <li><a href=\"\">ABS</a></li>
      <li><a href=\"\">COOLSCULPTING</a></li>
      <li><a href=\"\">ANTI AGE</a></li>
      <li><a href=\"\">INYECTABLES</a></li>
      <li><a href=\"\">CIRUGIAS</a></li>
      <li><a href=\"\">CONTACTENOS</a></li>
    </ul>
  </nav>
</header>

<section class=\"main-banner\">
  <picture class=\"main-banner-bg\">
    <source srcset=\"";
        // line 25
        echo $this->extensions['Drupal\Core\Template\TwigExtension']->escapeFilter($this->env, $this->extensions['Drupal\Core\Template\TwigExtension']->getFileUrl($this->sandbox->ensureToStringAllowed(twig_get_attribute($this->env, $this->source, twig_get_attribute($this->env, $this->source, twig_get_attribute($this->env, $this->source, twig_get_attribute($this->env, $this->source, ($context["node"] ?? null), "field_banner_desktop_image", [], "any", false, false, true, 25), "entity", [], "any", false, false, true, 25), "uri", [], "any", false, false, true, 25), "value", [], "any", false, false, true, 25), 25, $this->source)), "html", null, true);
        echo "\" media=\"(min-width: 1024px)\">
    <img src=\"";
        // line 26
        echo $this->extensions['Drupal\Core\Template\TwigExtension']->escapeFilter($this->env, $this->extensions['Drupal\Core\Template\TwigExtension']->getFileUrl($this->sandbox->ensureToStringAllowed(twig_get_attribute($this->env, $this->source, twig_get_attribute($this->env, $this->source, twig_get_attribute($this->env, $this->source, twig_get_attribute($this->env, $this->source, ($context["node"] ?? null), "field_banner_mobile_image", [], "any", false, false, true, 26), "entity", [], "any", false, false, true, 26), "uri", [], "any", false, false, true, 26), "value", [], "any", false, false, true, 26), 26, $this->source)), "html", null, true);
        echo "\" width=\"100%\" height=\"100%\"
         alt=\"";
        // line 27
        echo $this->extensions['Drupal\Core\Template\TwigExtension']->escapeFilter($this->env, $this->sandbox->ensureToStringAllowed(twig_get_attribute($this->env, $this->source, twig_get_attribute($this->env, $this->source, ($context["node"] ?? null), "field_banner_mobile_image", [], "any", false, false, true, 27), "alt", [], "any", false, false, true, 27), 27, $this->source), "html", null, true);
        echo "\"/>
  </picture>
  <article class=\"main-banner-info\">
    ";
        // line 30
        echo $this->extensions['Drupal\Core\Template\TwigExtension']->renderVar($this->sandbox->ensureToStringAllowed(twig_get_attribute($this->env, $this->source, twig_get_attribute($this->env, $this->source, ($context["node"] ?? null), "field_banner_text", [], "any", false, false, true, 30), "value", [], "any", false, false, true, 30), 30, $this->source));
        echo "
    <a href=\"";
        // line 31
        echo $this->extensions['Drupal\Core\Template\TwigExtension']->escapeFilter($this->env, $this->sandbox->ensureToStringAllowed(twig_get_attribute($this->env, $this->source, twig_get_attribute($this->env, $this->source, twig_get_attribute($this->env, $this->source, ($context["node"] ?? null), "field_banner_button", [], "any", false, false, true, 31), 0, [], "any", false, false, true, 31), "url", [], "any", false, false, true, 31), 31, $this->source), "html", null, true);
        echo "\">";
        echo $this->extensions['Drupal\Core\Template\TwigExtension']->escapeFilter($this->env, $this->sandbox->ensureToStringAllowed(twig_get_attribute($this->env, $this->source, twig_get_attribute($this->env, $this->source, twig_get_attribute($this->env, $this->source, ($context["node"] ?? null), "field_banner_button", [], "any", false, false, true, 31), 0, [], "any", false, false, true, 31), "title", [], "any", false, false, true, 31), 31, $this->source), "html", null, true);
        echo "</a>
  </article>
</section>

<section class=\"banner-info\">
  <p class=\"description\">
    ";
        // line 37
        echo $this->extensions['Drupal\Core\Template\TwigExtension']->escapeFilter($this->env, $this->sandbox->ensureToStringAllowed(twig_get_attribute($this->env, $this->source, twig_get_attribute($this->env, $this->source, ($context["node"] ?? null), "field_banner_footer", [], "any", false, false, true, 37), "value", [], "any", false, false, true, 37), 37, $this->source), "html", null, true);
        echo "
  </p>
</section>

<section class=\"second-banner\">
  <div class=\"container\">
    <picture class=\"img-title\">
      <source srcset=\"";
        // line 44
        echo $this->extensions['Drupal\Core\Template\TwigExtension']->escapeFilter($this->env, $this->extensions['Drupal\Core\Template\TwigExtension']->getFileUrl($this->sandbox->ensureToStringAllowed(twig_get_attribute($this->env, $this->source, twig_get_attribute($this->env, $this->source, twig_get_attribute($this->env, $this->source, twig_get_attribute($this->env, $this->source, ($context["node"] ?? null), "field_second_banner_destop_image", [], "any", false, false, true, 44), "entity", [], "any", false, false, true, 44), "uri", [], "any", false, false, true, 44), "value", [], "any", false, false, true, 44), 44, $this->source)), "html", null, true);
        echo "\" media=\"(min-width: 1024px)\">
      <img src=\"";
        // line 45
        echo $this->extensions['Drupal\Core\Template\TwigExtension']->escapeFilter($this->env, $this->extensions['Drupal\Core\Template\TwigExtension']->getFileUrl($this->sandbox->ensureToStringAllowed(twig_get_attribute($this->env, $this->source, twig_get_attribute($this->env, $this->source, twig_get_attribute($this->env, $this->source, twig_get_attribute($this->env, $this->source, ($context["node"] ?? null), "field_second_banner_mobile_image", [], "any", false, false, true, 45), "entity", [], "any", false, false, true, 45), "uri", [], "any", false, false, true, 45), "value", [], "any", false, false, true, 45), 45, $this->source)), "html", null, true);
        echo "\" width=\"100%\" height=\"100%\"
           alt=\"";
        // line 46
        echo $this->extensions['Drupal\Core\Template\TwigExtension']->escapeFilter($this->env, $this->sandbox->ensureToStringAllowed(twig_get_attribute($this->env, $this->source, twig_get_attribute($this->env, $this->source, ($context["node"] ?? null), "field_second_banner_mobile_image", [], "any", false, false, true, 46), "alt", [], "any", false, false, true, 46), 46, $this->source), "html", null, true);
        echo "\"/>
    </picture>
    <p class=\"description\">";
        // line 48
        echo $this->extensions['Drupal\Core\Template\TwigExtension']->escapeFilter($this->env, $this->sandbox->ensureToStringAllowed(twig_get_attribute($this->env, $this->source, twig_get_attribute($this->env, $this->source, ($context["node"] ?? null), "field_second_banner_text", [], "any", false, false, true, 48), "value", [], "any", false, false, true, 48), 48, $this->source), "html", null, true);
        echo "</p>
    <a href=\"";
        // line 49
        echo $this->extensions['Drupal\Core\Template\TwigExtension']->escapeFilter($this->env, $this->sandbox->ensureToStringAllowed(twig_get_attribute($this->env, $this->source, twig_get_attribute($this->env, $this->source, twig_get_attribute($this->env, $this->source, ($context["node"] ?? null), "field_second_banner_button", [], "any", false, false, true, 49), 0, [], "any", false, false, true, 49), "url", [], "any", false, false, true, 49), 49, $this->source), "html", null, true);
        echo "\" class=\"btn-show-more\">";
        echo $this->extensions['Drupal\Core\Template\TwigExtension']->escapeFilter($this->env, $this->sandbox->ensureToStringAllowed(twig_get_attribute($this->env, $this->source, twig_get_attribute($this->env, $this->source, twig_get_attribute($this->env, $this->source, ($context["node"] ?? null), "field_second_banner_button", [], "any", false, false, true, 49), 0, [], "any", false, false, true, 49), "title", [], "any", false, false, true, 49), 49, $this->source), "html", null, true);
        echo "</a>
  </div>

</section>

<section class=\"third-banner\">
  <article class=\"first-wrapper\">
    <img src=\"";
        // line 56
        echo $this->extensions['Drupal\Core\Template\TwigExtension']->escapeFilter($this->env, $this->extensions['Drupal\Core\Template\TwigExtension']->getFileUrl($this->sandbox->ensureToStringAllowed(twig_get_attribute($this->env, $this->source, twig_get_attribute($this->env, $this->source, twig_get_attribute($this->env, $this->source, twig_get_attribute($this->env, $this->source, ($context["node"] ?? null), "field_third_banner_image_right", [], "any", false, false, true, 56), "entity", [], "any", false, false, true, 56), "uri", [], "any", false, false, true, 56), "value", [], "any", false, false, true, 56), 56, $this->source)), "html", null, true);
        echo "\" width=\"100%\" height=\"100%\"
         alt=\"";
        // line 57
        echo $this->extensions['Drupal\Core\Template\TwigExtension']->escapeFilter($this->env, $this->sandbox->ensureToStringAllowed(twig_get_attribute($this->env, $this->source, twig_get_attribute($this->env, $this->source, ($context["node"] ?? null), "field_third_banner_image_right", [], "any", false, false, true, 57), "alt", [], "any", false, false, true, 57), 57, $this->source), "html", null, true);
        echo "\">
  </article>
  <img class=\"machine\" src=\"";
        // line 59
        echo $this->extensions['Drupal\Core\Template\TwigExtension']->escapeFilter($this->env, $this->extensions['Drupal\Core\Template\TwigExtension']->getFileUrl($this->sandbox->ensureToStringAllowed(twig_get_attribute($this->env, $this->source, twig_get_attribute($this->env, $this->source, twig_get_attribute($this->env, $this->source, twig_get_attribute($this->env, $this->source, ($context["node"] ?? null), "field_third_banner_image_central", [], "any", false, false, true, 59), "entity", [], "any", false, false, true, 59), "uri", [], "any", false, false, true, 59), "value", [], "any", false, false, true, 59), 59, $this->source)), "html", null, true);
        echo "\"
       alt=\"";
        // line 60
        echo $this->extensions['Drupal\Core\Template\TwigExtension']->escapeFilter($this->env, $this->sandbox->ensureToStringAllowed(twig_get_attribute($this->env, $this->source, twig_get_attribute($this->env, $this->source, ($context["node"] ?? null), "field_third_banner_image_central", [], "any", false, false, true, 60), "alt", [], "any", false, false, true, 60), 60, $this->source), "html", null, true);
        echo "\">
  <article class=\"second-wrapper\">
    <img class=\"bg-pattern\" src=\"";
        // line 62
        echo $this->extensions['Drupal\Core\Template\TwigExtension']->escapeFilter($this->env, $this->extensions['Drupal\Core\Template\TwigExtension']->getFileUrl($this->sandbox->ensureToStringAllowed(twig_get_attribute($this->env, $this->source, twig_get_attribute($this->env, $this->source, twig_get_attribute($this->env, $this->source, twig_get_attribute($this->env, $this->source, ($context["node"] ?? null), "field_third_banner_image_left", [], "any", false, false, true, 62), "entity", [], "any", false, false, true, 62), "uri", [], "any", false, false, true, 62), "value", [], "any", false, false, true, 62), 62, $this->source)), "html", null, true);
        echo "\" width=\"100%\" height=\"100%\"
         alt=\"";
        // line 63
        echo $this->extensions['Drupal\Core\Template\TwigExtension']->escapeFilter($this->env, $this->sandbox->ensureToStringAllowed(twig_get_attribute($this->env, $this->source, twig_get_attribute($this->env, $this->source, ($context["node"] ?? null), "field_third_banner_image_left", [], "any", false, false, true, 63), "alt", [], "any", false, false, true, 63), 63, $this->source), "html", null, true);
        echo "\">
    <img class=\"title\" src=\"";
        // line 64
        echo $this->extensions['Drupal\Core\Template\TwigExtension']->escapeFilter($this->env, $this->extensions['Drupal\Core\Template\TwigExtension']->getFileUrl($this->sandbox->ensureToStringAllowed(twig_get_attribute($this->env, $this->source, twig_get_attribute($this->env, $this->source, twig_get_attribute($this->env, $this->source, twig_get_attribute($this->env, $this->source, ($context["node"] ?? null), "field_third_banner_image_title", [], "any", false, false, true, 64), "entity", [], "any", false, false, true, 64), "uri", [], "any", false, false, true, 64), "value", [], "any", false, false, true, 64), 64, $this->source)), "html", null, true);
        echo "\" width=\"100%\" height=\"100%\"
         alt=\"";
        // line 65
        echo $this->extensions['Drupal\Core\Template\TwigExtension']->escapeFilter($this->env, $this->sandbox->ensureToStringAllowed(twig_get_attribute($this->env, $this->source, twig_get_attribute($this->env, $this->source, ($context["node"] ?? null), "field_third_banner_image_title", [], "any", false, false, true, 65), "alt", [], "any", false, false, true, 65), 65, $this->source), "html", null, true);
        echo "\" >
    <img class=\"description\" src=\"";
        // line 66
        echo $this->extensions['Drupal\Core\Template\TwigExtension']->escapeFilter($this->env, $this->extensions['Drupal\Core\Template\TwigExtension']->getFileUrl($this->sandbox->ensureToStringAllowed(twig_get_attribute($this->env, $this->source, twig_get_attribute($this->env, $this->source, twig_get_attribute($this->env, $this->source, twig_get_attribute($this->env, $this->source, ($context["node"] ?? null), "field_third_banner_image_text", [], "any", false, false, true, 66), "entity", [], "any", false, false, true, 66), "uri", [], "any", false, false, true, 66), "value", [], "any", false, false, true, 66), 66, $this->source)), "html", null, true);
        echo "\"
         alt=\"";
        // line 67
        echo $this->extensions['Drupal\Core\Template\TwigExtension']->escapeFilter($this->env, $this->sandbox->ensureToStringAllowed(twig_get_attribute($this->env, $this->source, twig_get_attribute($this->env, $this->source, ($context["node"] ?? null), "field_third_banner_image_text", [], "any", false, false, true, 67), "alt", [], "any", false, false, true, 67), 67, $this->source), "html", null, true);
        echo "\" >
    <a class=\"cta-btn\" href=\"";
        // line 68
        echo $this->extensions['Drupal\Core\Template\TwigExtension']->escapeFilter($this->env, $this->sandbox->ensureToStringAllowed(twig_get_attribute($this->env, $this->source, twig_get_attribute($this->env, $this->source, twig_get_attribute($this->env, $this->source, ($context["node"] ?? null), "field_second_banner_button", [], "any", false, false, true, 68), 0, [], "any", false, false, true, 68), "url", [], "any", false, false, true, 68), 68, $this->source), "html", null, true);
        echo "\">
      ";
        // line 69
        echo $this->extensions['Drupal\Core\Template\TwigExtension']->escapeFilter($this->env, $this->sandbox->ensureToStringAllowed(twig_get_attribute($this->env, $this->source, twig_get_attribute($this->env, $this->source, twig_get_attribute($this->env, $this->source, ($context["node"] ?? null), "field_second_banner_button", [], "any", false, false, true, 69), 0, [], "any", false, false, true, 69), "title", [], "any", false, false, true, 69), 69, $this->source), "html", null, true);
        echo "</a>
  </article>
</section>

<section class=\"antiage-banner\">
  <article class=\"first-wrapper\">
    <img src=\"";
        // line 75
        echo $this->extensions['Drupal\Core\Template\TwigExtension']->escapeFilter($this->env, $this->extensions['Drupal\Core\Template\TwigExtension']->getFileUrl($this->sandbox->ensureToStringAllowed(twig_get_attribute($this->env, $this->source, twig_get_attribute($this->env, $this->source, twig_get_attribute($this->env, $this->source, twig_get_attribute($this->env, $this->source, ($context["node"] ?? null), "field_fourth_banner_image_left", [], "any", false, false, true, 75), "entity", [], "any", false, false, true, 75), "uri", [], "any", false, false, true, 75), "value", [], "any", false, false, true, 75), 75, $this->source)), "html", null, true);
        echo "\" width=\"100%\" height=\"100%\"
         alt=\"";
        // line 76
        echo $this->extensions['Drupal\Core\Template\TwigExtension']->escapeFilter($this->env, $this->sandbox->ensureToStringAllowed(twig_get_attribute($this->env, $this->source, twig_get_attribute($this->env, $this->source, ($context["node"] ?? null), "field_fourth_banner_image_left", [], "any", false, false, true, 76), "alt", [], "any", false, false, true, 76), 76, $this->source), "html", null, true);
        echo "\"/>
    <img class=\"antiage-brand\" src=\"";
        // line 77
        echo $this->extensions['Drupal\Core\Template\TwigExtension']->escapeFilter($this->env, $this->extensions['Drupal\Core\Template\TwigExtension']->getFileUrl($this->sandbox->ensureToStringAllowed(twig_get_attribute($this->env, $this->source, twig_get_attribute($this->env, $this->source, twig_get_attribute($this->env, $this->source, twig_get_attribute($this->env, $this->source, ($context["node"] ?? null), "field_fourth_banner_image_centra", [], "any", false, false, true, 77), "entity", [], "any", false, false, true, 77), "uri", [], "any", false, false, true, 77), "value", [], "any", false, false, true, 77), 77, $this->source)), "html", null, true);
        echo "\"
         alt=\"";
        // line 78
        echo $this->extensions['Drupal\Core\Template\TwigExtension']->escapeFilter($this->env, $this->sandbox->ensureToStringAllowed(twig_get_attribute($this->env, $this->source, twig_get_attribute($this->env, $this->source, ($context["node"] ?? null), "field_fourth_banner_image_centra", [], "any", false, false, true, 78), "alt", [], "any", false, false, true, 78), 78, $this->source), "html", null, true);
        echo "\">
  </article>
  <article class=\"second-wrapper\">
    <img class=\"bg-pattern\" src=\"";
        // line 81
        echo $this->extensions['Drupal\Core\Template\TwigExtension']->escapeFilter($this->env, $this->extensions['Drupal\Core\Template\TwigExtension']->getFileUrl($this->sandbox->ensureToStringAllowed(twig_get_attribute($this->env, $this->source, twig_get_attribute($this->env, $this->source, twig_get_attribute($this->env, $this->source, twig_get_attribute($this->env, $this->source, ($context["node"] ?? null), "field_fourth_banner_image_right", [], "any", false, false, true, 81), "entity", [], "any", false, false, true, 81), "uri", [], "any", false, false, true, 81), "value", [], "any", false, false, true, 81), 81, $this->source)), "html", null, true);
        echo "\" width=\"100%\" height=\"100%\"
         alt=\"";
        // line 82
        echo $this->extensions['Drupal\Core\Template\TwigExtension']->escapeFilter($this->env, $this->sandbox->ensureToStringAllowed(twig_get_attribute($this->env, $this->source, twig_get_attribute($this->env, $this->source, ($context["node"] ?? null), "field_fourth_banner_image_right", [], "any", false, false, true, 82), "alt", [], "any", false, false, true, 82), 82, $this->source), "html", null, true);
        echo "\">
    <p class=\"antiage-description\">
      ";
        // line 84
        echo $this->extensions['Drupal\Core\Template\TwigExtension']->escapeFilter($this->env, $this->sandbox->ensureToStringAllowed(twig_get_attribute($this->env, $this->source, twig_get_attribute($this->env, $this->source, ($context["node"] ?? null), "field_fourth_banner_text", [], "any", false, false, true, 84), "value", [], "any", false, false, true, 84), 84, $this->source), "html", null, true);
        echo "
    </p>
    <a class=\"antiage-cta\" href=\"";
        // line 86
        echo $this->extensions['Drupal\Core\Template\TwigExtension']->escapeFilter($this->env, $this->sandbox->ensureToStringAllowed(twig_get_attribute($this->env, $this->source, twig_get_attribute($this->env, $this->source, twig_get_attribute($this->env, $this->source, ($context["node"] ?? null), "field_fourth_banner_button", [], "any", false, false, true, 86), 0, [], "any", false, false, true, 86), "url", [], "any", false, false, true, 86), 86, $this->source), "html", null, true);
        echo "\">
      ";
        // line 87
        echo $this->extensions['Drupal\Core\Template\TwigExtension']->escapeFilter($this->env, $this->sandbox->ensureToStringAllowed(twig_get_attribute($this->env, $this->source, twig_get_attribute($this->env, $this->source, twig_get_attribute($this->env, $this->source, ($context["node"] ?? null), "field_fourth_banner_button", [], "any", false, false, true, 87), 0, [], "any", false, false, true, 87), "title", [], "any", false, false, true, 87), 87, $this->source), "html", null, true);
        echo "</a>
  </article>
</section>

<section class=\"rejuvenece-banner\">

  <picture class=\"first-image\">
    <source srcset=\"";
        // line 94
        echo $this->extensions['Drupal\Core\Template\TwigExtension']->escapeFilter($this->env, $this->extensions['Drupal\Core\Template\TwigExtension']->getFileUrl($this->sandbox->ensureToStringAllowed(twig_get_attribute($this->env, $this->source, twig_get_attribute($this->env, $this->source, twig_get_attribute($this->env, $this->source, twig_get_attribute($this->env, $this->source, ($context["node"] ?? null), "field_fifth_banner_background_de", [], "any", false, false, true, 94), "entity", [], "any", false, false, true, 94), "uri", [], "any", false, false, true, 94), "value", [], "any", false, false, true, 94), 94, $this->source)), "html", null, true);
        echo "\" media=\"(min-width: 1024px)\">
    <img src=\"";
        // line 95
        echo $this->extensions['Drupal\Core\Template\TwigExtension']->escapeFilter($this->env, $this->extensions['Drupal\Core\Template\TwigExtension']->getFileUrl($this->sandbox->ensureToStringAllowed(twig_get_attribute($this->env, $this->source, twig_get_attribute($this->env, $this->source, twig_get_attribute($this->env, $this->source, twig_get_attribute($this->env, $this->source, ($context["node"] ?? null), "field_fifth_banner_background_mo", [], "any", false, false, true, 95), "entity", [], "any", false, false, true, 95), "uri", [], "any", false, false, true, 95), "value", [], "any", false, false, true, 95), 95, $this->source)), "html", null, true);
        echo "\" width=\"100%\" height=\"100%\"
         alt=\"";
        // line 96
        echo $this->extensions['Drupal\Core\Template\TwigExtension']->escapeFilter($this->env, $this->sandbox->ensureToStringAllowed(twig_get_attribute($this->env, $this->source, twig_get_attribute($this->env, $this->source, ($context["node"] ?? null), "field_fifth_banner_background_de", [], "any", false, false, true, 96), "alt", [], "any", false, false, true, 96), 96, $this->source), "html", null, true);
        echo "\"/>
  </picture>

  <picture class=\"second-image\">
    <source srcset=\"";
        // line 100
        echo $this->extensions['Drupal\Core\Template\TwigExtension']->escapeFilter($this->env, $this->extensions['Drupal\Core\Template\TwigExtension']->getFileUrl($this->sandbox->ensureToStringAllowed(twig_get_attribute($this->env, $this->source, twig_get_attribute($this->env, $this->source, twig_get_attribute($this->env, $this->source, twig_get_attribute($this->env, $this->source, ($context["node"] ?? null), "field_fifth_banner_text_desktop_", [], "any", false, false, true, 100), "entity", [], "any", false, false, true, 100), "uri", [], "any", false, false, true, 100), "value", [], "any", false, false, true, 100), 100, $this->source)), "html", null, true);
        echo "\" media=\"(min-width: 1024px)\">
    <img src=\"";
        // line 101
        echo $this->extensions['Drupal\Core\Template\TwigExtension']->escapeFilter($this->env, $this->extensions['Drupal\Core\Template\TwigExtension']->getFileUrl($this->sandbox->ensureToStringAllowed(twig_get_attribute($this->env, $this->source, twig_get_attribute($this->env, $this->source, twig_get_attribute($this->env, $this->source, twig_get_attribute($this->env, $this->source, ($context["node"] ?? null), "field_fifth_banner_text_mobile_i", [], "any", false, false, true, 101), "entity", [], "any", false, false, true, 101), "uri", [], "any", false, false, true, 101), "value", [], "any", false, false, true, 101), 101, $this->source)), "html", null, true);
        echo "\" width=\"100%\" height=\"100%\"
         alt=\"";
        // line 102
        echo $this->extensions['Drupal\Core\Template\TwigExtension']->escapeFilter($this->env, $this->sandbox->ensureToStringAllowed(twig_get_attribute($this->env, $this->source, twig_get_attribute($this->env, $this->source, ($context["node"] ?? null), "field_fifth_banner_text_desktop_", [], "any", false, false, true, 102), "alt", [], "any", false, false, true, 102), 102, $this->source), "html", null, true);
        echo "\"/>
  </picture>

</section>

<section class=\"reviews\">
  <div class=\"splide\" aria-label=\"slider reviews\">
    <div class=\"splide__track\">
      <ul class=\"splide__list\">
        ";
        // line 111
        $context['_parent'] = $context;
        $context['_seq'] = twig_ensure_traversable(twig_get_attribute($this->env, $this->source, ($context["node"] ?? null), "field_slider_customers", [], "any", false, false, true, 111));
        foreach ($context['_seq'] as $context["_key"] => $context["item"]) {
            // line 112
            echo "          <li class=\"splide__slide\">
            <h3>";
            // line 113
            echo $this->extensions['Drupal\Core\Template\TwigExtension']->escapeFilter($this->env, $this->sandbox->ensureToStringAllowed(twig_get_attribute($this->env, $this->source, twig_get_attribute($this->env, $this->source, twig_get_attribute($this->env, $this->source, $context["item"], "entity", [], "any", false, false, true, 113), "field_title", [], "any", false, false, true, 113), "value", [], "any", false, false, true, 113), 113, $this->source), "html", null, true);
            echo "</h3>
            <hr>
            <p>
              ";
            // line 116
            echo $this->extensions['Drupal\Core\Template\TwigExtension']->escapeFilter($this->env, $this->sandbox->ensureToStringAllowed(twig_get_attribute($this->env, $this->source, twig_get_attribute($this->env, $this->source, twig_get_attribute($this->env, $this->source, $context["item"], "entity", [], "any", false, false, true, 116), "field_description", [], "any", false, false, true, 116), "value", [], "any", false, false, true, 116), 116, $this->source), "html", null, true);
            echo "
            </p>
          </li>
        ";
        }
        $_parent = $context['_parent'];
        unset($context['_seq'], $context['_iterated'], $context['_key'], $context['item'], $context['_parent'], $context['loop']);
        $context = array_intersect_key($context, $_parent) + $_parent;
        // line 120
        echo "      </ul>
    </div>
  </div>
</section>

<!-- INSERTAR AQUI EL MAPA -->
<!-- 
    <section class=\"map\">

    </section> -->

<section class=\"form\">
  <form class=\"form-contact\">
    <div class=\"form-wrapper\">
      <label for=\"name\">Nombre*</label>
      <input type=\"text\" name=\"name\" placeholder=\"Ingresa tu nombre\">
    </div>
    <div class=\"form-wrapper\">
      <label for=\"address\">Direccion</label>
      <input type=\"text\" name=\"address\" placeholder=\"Ingresa tu dirección\">
    </div>

    <div class=\"form-wrapper form-wrapper__contact\">
      <label for=\"name\">Email*</label>
      <input type=\"email\" name=\"email\" placeholder=\"Ingresa tu email\">
    </div>

    <div class=\"form-wrapper form-wrapper__contact\">
      <label for=\"phone\">Teléfono</label>
      <input type=\"text\" name=\"phone\" placeholder=\"Ingresa tu número de telefono\">
    </div>

    <div class=\"form-wrapper\">
      <label for=\"subject\">Asunto</label>
      <input type=\"text\" name=\"subject\" placeholder=\"Ingresa el asunto\">
    </div>

    <div class=\"form-wrapper\">
      <label for=\"message\">Mensaje</label>
      <textarea name=\"message\"cols=\"30\" rows=\"10\" placeholder=\"Escribe tu mensaje\"></textarea>
    </div>

    <button class=\"form-cta\" type=\"submit\">ENVIAR</button>
  </form>
</section>

<footer class=\"footer\" id=\"form\">
  <section class=\"social\">
    <a href=\"instagram\"><img src=\"/themes/custom/theme_dr_mario/assets/img/instagram-logo.png\" alt=\"instagram logo\"></a>
    <a href=\"facebook\"><img src=\"/themes/custom/theme_dr_mario/assets/img/facebook-logo.png\" alt=\"facebook logo\"></a>
    <a href=\"youtube\"><img src=\"/themes/custom/theme_dr_mario/assets/img/youtube-logo.png\" alt=\"youtube logo\"></a>
  </section>
  <img class=\"logo\" src=\"/themes/custom/theme_dr_mario/assets/img/mario-arcila-logo.png\" alt=\"Mario arcila logo\">
</footer>



";
    }

    public function getTemplateName()
    {
        return "themes/custom/theme_dr_mario/templates/page--node--2.html.twig";
    }

    public function isTraitable()
    {
        return false;
    }

    public function getDebugInfo()
    {
        return array (  292 => 120,  282 => 116,  276 => 113,  273 => 112,  269 => 111,  257 => 102,  253 => 101,  249 => 100,  242 => 96,  238 => 95,  234 => 94,  224 => 87,  220 => 86,  215 => 84,  210 => 82,  206 => 81,  200 => 78,  196 => 77,  192 => 76,  188 => 75,  179 => 69,  175 => 68,  171 => 67,  167 => 66,  163 => 65,  159 => 64,  155 => 63,  151 => 62,  146 => 60,  142 => 59,  137 => 57,  133 => 56,  121 => 49,  117 => 48,  112 => 46,  108 => 45,  104 => 44,  94 => 37,  83 => 31,  79 => 30,  73 => 27,  69 => 26,  65 => 25,  39 => 1,);
    }

    public function getSourceContext()
    {
        return new Source("", "themes/custom/theme_dr_mario/templates/page--node--2.html.twig", "/var/www/html/web/themes/custom/theme_dr_mario/templates/page--node--2.html.twig");
    }
    
    public function checkSecurity()
    {
        static $tags = array("for" => 111);
        static $filters = array("escape" => 25, "raw" => 30);
        static $functions = array("file_url" => 25);

        try {
            $this->sandbox->checkSecurity(
                ['for'],
                ['escape', 'raw'],
                ['file_url']
            );
        } catch (SecurityError $e) {
            $e->setSourceContext($this->source);

            if ($e instanceof SecurityNotAllowedTagError && isset($tags[$e->getTagName()])) {
                $e->setTemplateLine($tags[$e->getTagName()]);
            } elseif ($e instanceof SecurityNotAllowedFilterError && isset($filters[$e->getFilterName()])) {
                $e->setTemplateLine($filters[$e->getFilterName()]);
            } elseif ($e instanceof SecurityNotAllowedFunctionError && isset($functions[$e->getFunctionName()])) {
                $e->setTemplateLine($functions[$e->getFunctionName()]);
            }

            throw $e;
        }

    }
}
