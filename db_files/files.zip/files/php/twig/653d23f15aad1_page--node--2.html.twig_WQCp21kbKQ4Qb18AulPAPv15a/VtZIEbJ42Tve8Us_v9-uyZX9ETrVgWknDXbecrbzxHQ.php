<?php

use Twig\Environment;
use Twig\Error\LoaderError;
use Twig\Error\RuntimeError;
use Twig\Extension\SandboxExtension;
use Twig\Markup;
use Twig\Sandbox\SecurityError;
use Twig\Sandbox\SecurityNotAllowedTagError;
use Twig\Sandbox\SecurityNotAllowedFilterError;
use Twig\Sandbox\SecurityNotAllowedFunctionError;
use Twig\Source;
use Twig\Template;

/* themes/custom/theme_dr_mario/templates/page--node--2.html.twig */
class __TwigTemplate_12a0d69d77afac3c5f7c1bd32b136a2b extends Template
{
    private $source;
    private $macros = [];

    public function __construct(Environment $env)
    {
        parent::__construct($env);

        $this->source = $this->getSourceContext();

        $this->parent = false;

        $this->blocks = [
        ];
        $this->sandbox = $this->env->getExtension('\Twig\Extension\SandboxExtension');
        $this->checkSecurity();
    }

    protected function doDisplay(array $context, array $blocks = [])
    {
        $macros = $this->macros;
        // line 1
        echo "<header class=\"header\">
  <nav>
    <div class=\"logo-wrapper\">
      <a>
        <img class=\"logo\" src=\"";
        // line 5
        echo $this->extensions['Drupal\Core\Template\TwigExtension']->escapeFilter($this->env, $this->extensions['Drupal\Core\Template\TwigExtension']->getFileUrl($this->sandbox->ensureToStringAllowed(twig_get_attribute($this->env, $this->source, twig_get_attribute($this->env, $this->source, twig_get_attribute($this->env, $this->source, twig_get_attribute($this->env, $this->source, ($context["node"] ?? null), "field_logo", [], "any", false, false, true, 5), "entity", [], "any", false, false, true, 5), "uri", [], "any", false, false, true, 5), "value", [], "any", false, false, true, 5), 5, $this->source)), "html", null, true);
        echo "\"
             alt=\"";
        // line 6
        echo $this->extensions['Drupal\Core\Template\TwigExtension']->escapeFilter($this->env, $this->sandbox->ensureToStringAllowed(twig_get_attribute($this->env, $this->source, twig_get_attribute($this->env, $this->source, ($context["node"] ?? null), "field_logo", [], "any", false, false, true, 6), "alt", [], "any", false, false, true, 6), 6, $this->source), "html", null, true);
        echo "\">
      </a>
    </div>
    <div class=\"burger-menu\">
      <span></span>
      <span></span>
      <span></span>
    </div>
    <ul class=\"menu-container\">
      ";
        // line 15
        $context['_parent'] = $context;
        $context['_seq'] = twig_ensure_traversable(twig_get_attribute($this->env, $this->source, ($context["node"] ?? null), "field_menu", [], "any", false, false, true, 15));
        foreach ($context['_seq'] as $context["_key"] => $context["item"]) {
            // line 16
            echo "        <li><a href=\"";
            echo $this->extensions['Drupal\Core\Template\TwigExtension']->escapeFilter($this->env, $this->sandbox->ensureToStringAllowed(twig_get_attribute($this->env, $this->source, twig_get_attribute($this->env, $this->source, twig_get_attribute($this->env, $this->source, $context["item"], "entity", [], "any", false, false, true, 16), "field_link", [], "any", false, false, true, 16), "value", [], "any", false, false, true, 16), 16, $this->source), "html", null, true);
            echo "\">";
            echo $this->extensions['Drupal\Core\Template\TwigExtension']->escapeFilter($this->env, $this->sandbox->ensureToStringAllowed(twig_get_attribute($this->env, $this->source, twig_get_attribute($this->env, $this->source, twig_get_attribute($this->env, $this->source, $context["item"], "entity", [], "any", false, false, true, 16), "field_menu_link_title", [], "any", false, false, true, 16), "value", [], "any", false, false, true, 16), 16, $this->source), "html", null, true);
            echo "</a></li>
      ";
        }
        $_parent = $context['_parent'];
        unset($context['_seq'], $context['_iterated'], $context['_key'], $context['item'], $context['_parent'], $context['loop']);
        $context = array_intersect_key($context, $_parent) + $_parent;
        // line 18
        echo "    </ul>
  </nav>
</header>

<section class=\"main-banner\">
  <picture class=\"main-banner-bg\">
    <source srcset=\"";
        // line 24
        echo $this->extensions['Drupal\Core\Template\TwigExtension']->escapeFilter($this->env, $this->extensions['Drupal\Core\Template\TwigExtension']->getFileUrl($this->sandbox->ensureToStringAllowed(twig_get_attribute($this->env, $this->source, twig_get_attribute($this->env, $this->source, twig_get_attribute($this->env, $this->source, twig_get_attribute($this->env, $this->source, ($context["node"] ?? null), "field_banner_desktop_image", [], "any", false, false, true, 24), "entity", [], "any", false, false, true, 24), "uri", [], "any", false, false, true, 24), "value", [], "any", false, false, true, 24), 24, $this->source)), "html", null, true);
        echo "\" media=\"(min-width: 1024px)\">
    <img src=\"";
        // line 25
        echo $this->extensions['Drupal\Core\Template\TwigExtension']->escapeFilter($this->env, $this->extensions['Drupal\Core\Template\TwigExtension']->getFileUrl($this->sandbox->ensureToStringAllowed(twig_get_attribute($this->env, $this->source, twig_get_attribute($this->env, $this->source, twig_get_attribute($this->env, $this->source, twig_get_attribute($this->env, $this->source, ($context["node"] ?? null), "field_banner_mobile_image", [], "any", false, false, true, 25), "entity", [], "any", false, false, true, 25), "uri", [], "any", false, false, true, 25), "value", [], "any", false, false, true, 25), 25, $this->source)), "html", null, true);
        echo "\" width=\"100%\" height=\"100%\"
         alt=\"";
        // line 26
        echo $this->extensions['Drupal\Core\Template\TwigExtension']->escapeFilter($this->env, $this->sandbox->ensureToStringAllowed(twig_get_attribute($this->env, $this->source, twig_get_attribute($this->env, $this->source, ($context["node"] ?? null), "field_banner_mobile_image", [], "any", false, false, true, 26), "alt", [], "any", false, false, true, 26), 26, $this->source), "html", null, true);
        echo "\"/>
  </picture>
  <article class=\"main-banner-info\">
    ";
        // line 29
        echo $this->extensions['Drupal\Core\Template\TwigExtension']->renderVar($this->sandbox->ensureToStringAllowed(twig_get_attribute($this->env, $this->source, twig_get_attribute($this->env, $this->source, ($context["node"] ?? null), "field_banner_text", [], "any", false, false, true, 29), "value", [], "any", false, false, true, 29), 29, $this->source));
        echo "
    <a href=\"";
        // line 30
        echo $this->extensions['Drupal\Core\Template\TwigExtension']->escapeFilter($this->env, $this->sandbox->ensureToStringAllowed(twig_get_attribute($this->env, $this->source, twig_get_attribute($this->env, $this->source, twig_get_attribute($this->env, $this->source, ($context["node"] ?? null), "field_banner_button", [], "any", false, false, true, 30), 0, [], "any", false, false, true, 30), "url", [], "any", false, false, true, 30), 30, $this->source), "html", null, true);
        echo "\">";
        echo $this->extensions['Drupal\Core\Template\TwigExtension']->escapeFilter($this->env, $this->sandbox->ensureToStringAllowed(twig_get_attribute($this->env, $this->source, twig_get_attribute($this->env, $this->source, twig_get_attribute($this->env, $this->source, ($context["node"] ?? null), "field_banner_button", [], "any", false, false, true, 30), 0, [], "any", false, false, true, 30), "title", [], "any", false, false, true, 30), 30, $this->source), "html", null, true);
        echo "</a>
  </article>
</section>

<section class=\"banner-info\">
  <p class=\"description\">
    ";
        // line 36
        echo $this->extensions['Drupal\Core\Template\TwigExtension']->escapeFilter($this->env, $this->sandbox->ensureToStringAllowed(twig_get_attribute($this->env, $this->source, twig_get_attribute($this->env, $this->source, ($context["node"] ?? null), "field_banner_footer", [], "any", false, false, true, 36), "value", [], "any", false, false, true, 36), 36, $this->source), "html", null, true);
        echo "
  </p>
</section>

<section class=\"second-banner\">
  <div class=\"container\">
    <picture class=\"img-title\">
      <source srcset=\"";
        // line 43
        echo $this->extensions['Drupal\Core\Template\TwigExtension']->escapeFilter($this->env, $this->extensions['Drupal\Core\Template\TwigExtension']->getFileUrl($this->sandbox->ensureToStringAllowed(twig_get_attribute($this->env, $this->source, twig_get_attribute($this->env, $this->source, twig_get_attribute($this->env, $this->source, twig_get_attribute($this->env, $this->source, ($context["node"] ?? null), "field_second_banner_destop_image", [], "any", false, false, true, 43), "entity", [], "any", false, false, true, 43), "uri", [], "any", false, false, true, 43), "value", [], "any", false, false, true, 43), 43, $this->source)), "html", null, true);
        echo "\" media=\"(min-width: 1024px)\">
      <img src=\"";
        // line 44
        echo $this->extensions['Drupal\Core\Template\TwigExtension']->escapeFilter($this->env, $this->extensions['Drupal\Core\Template\TwigExtension']->getFileUrl($this->sandbox->ensureToStringAllowed(twig_get_attribute($this->env, $this->source, twig_get_attribute($this->env, $this->source, twig_get_attribute($this->env, $this->source, twig_get_attribute($this->env, $this->source, ($context["node"] ?? null), "field_second_banner_mobile_image", [], "any", false, false, true, 44), "entity", [], "any", false, false, true, 44), "uri", [], "any", false, false, true, 44), "value", [], "any", false, false, true, 44), 44, $this->source)), "html", null, true);
        echo "\" width=\"100%\" height=\"100%\"
           alt=\"";
        // line 45
        echo $this->extensions['Drupal\Core\Template\TwigExtension']->escapeFilter($this->env, $this->sandbox->ensureToStringAllowed(twig_get_attribute($this->env, $this->source, twig_get_attribute($this->env, $this->source, ($context["node"] ?? null), "field_second_banner_mobile_image", [], "any", false, false, true, 45), "alt", [], "any", false, false, true, 45), 45, $this->source), "html", null, true);
        echo "\"/>
    </picture>
    <p class=\"description\">";
        // line 47
        echo $this->extensions['Drupal\Core\Template\TwigExtension']->escapeFilter($this->env, $this->sandbox->ensureToStringAllowed(twig_get_attribute($this->env, $this->source, twig_get_attribute($this->env, $this->source, ($context["node"] ?? null), "field_second_banner_text", [], "any", false, false, true, 47), "value", [], "any", false, false, true, 47), 47, $this->source), "html", null, true);
        echo "</p>
    <a href=\"";
        // line 48
        echo $this->extensions['Drupal\Core\Template\TwigExtension']->escapeFilter($this->env, $this->sandbox->ensureToStringAllowed(twig_get_attribute($this->env, $this->source, twig_get_attribute($this->env, $this->source, twig_get_attribute($this->env, $this->source, ($context["node"] ?? null), "field_second_banner_button", [], "any", false, false, true, 48), 0, [], "any", false, false, true, 48), "url", [], "any", false, false, true, 48), 48, $this->source), "html", null, true);
        echo "\" class=\"btn-show-more\">";
        echo $this->extensions['Drupal\Core\Template\TwigExtension']->escapeFilter($this->env, $this->sandbox->ensureToStringAllowed(twig_get_attribute($this->env, $this->source, twig_get_attribute($this->env, $this->source, twig_get_attribute($this->env, $this->source, ($context["node"] ?? null), "field_second_banner_button", [], "any", false, false, true, 48), 0, [], "any", false, false, true, 48), "title", [], "any", false, false, true, 48), 48, $this->source), "html", null, true);
        echo "</a>
  </div>

</section>

<section class=\"third-banner\">
  <article class=\"first-wrapper\">
    <img src=\"";
        // line 55
        echo $this->extensions['Drupal\Core\Template\TwigExtension']->escapeFilter($this->env, $this->extensions['Drupal\Core\Template\TwigExtension']->getFileUrl($this->sandbox->ensureToStringAllowed(twig_get_attribute($this->env, $this->source, twig_get_attribute($this->env, $this->source, twig_get_attribute($this->env, $this->source, twig_get_attribute($this->env, $this->source, ($context["node"] ?? null), "field_third_banner_image_right", [], "any", false, false, true, 55), "entity", [], "any", false, false, true, 55), "uri", [], "any", false, false, true, 55), "value", [], "any", false, false, true, 55), 55, $this->source)), "html", null, true);
        echo "\" width=\"100%\" height=\"100%\"
         alt=\"";
        // line 56
        echo $this->extensions['Drupal\Core\Template\TwigExtension']->escapeFilter($this->env, $this->sandbox->ensureToStringAllowed(twig_get_attribute($this->env, $this->source, twig_get_attribute($this->env, $this->source, ($context["node"] ?? null), "field_third_banner_image_right", [], "any", false, false, true, 56), "alt", [], "any", false, false, true, 56), 56, $this->source), "html", null, true);
        echo "\">
  </article>
  <img class=\"machine\" src=\"";
        // line 58
        echo $this->extensions['Drupal\Core\Template\TwigExtension']->escapeFilter($this->env, $this->extensions['Drupal\Core\Template\TwigExtension']->getFileUrl($this->sandbox->ensureToStringAllowed(twig_get_attribute($this->env, $this->source, twig_get_attribute($this->env, $this->source, twig_get_attribute($this->env, $this->source, twig_get_attribute($this->env, $this->source, ($context["node"] ?? null), "field_third_banner_image_central", [], "any", false, false, true, 58), "entity", [], "any", false, false, true, 58), "uri", [], "any", false, false, true, 58), "value", [], "any", false, false, true, 58), 58, $this->source)), "html", null, true);
        echo "\"
       alt=\"";
        // line 59
        echo $this->extensions['Drupal\Core\Template\TwigExtension']->escapeFilter($this->env, $this->sandbox->ensureToStringAllowed(twig_get_attribute($this->env, $this->source, twig_get_attribute($this->env, $this->source, ($context["node"] ?? null), "field_third_banner_image_central", [], "any", false, false, true, 59), "alt", [], "any", false, false, true, 59), 59, $this->source), "html", null, true);
        echo "\">
  <article class=\"second-wrapper\">
    <img class=\"bg-pattern\" src=\"";
        // line 61
        echo $this->extensions['Drupal\Core\Template\TwigExtension']->escapeFilter($this->env, $this->extensions['Drupal\Core\Template\TwigExtension']->getFileUrl($this->sandbox->ensureToStringAllowed(twig_get_attribute($this->env, $this->source, twig_get_attribute($this->env, $this->source, twig_get_attribute($this->env, $this->source, twig_get_attribute($this->env, $this->source, ($context["node"] ?? null), "field_third_banner_image_left", [], "any", false, false, true, 61), "entity", [], "any", false, false, true, 61), "uri", [], "any", false, false, true, 61), "value", [], "any", false, false, true, 61), 61, $this->source)), "html", null, true);
        echo "\" width=\"100%\" height=\"100%\"
         alt=\"";
        // line 62
        echo $this->extensions['Drupal\Core\Template\TwigExtension']->escapeFilter($this->env, $this->sandbox->ensureToStringAllowed(twig_get_attribute($this->env, $this->source, twig_get_attribute($this->env, $this->source, ($context["node"] ?? null), "field_third_banner_image_left", [], "any", false, false, true, 62), "alt", [], "any", false, false, true, 62), 62, $this->source), "html", null, true);
        echo "\">
    <img class=\"title\" src=\"";
        // line 63
        echo $this->extensions['Drupal\Core\Template\TwigExtension']->escapeFilter($this->env, $this->extensions['Drupal\Core\Template\TwigExtension']->getFileUrl($this->sandbox->ensureToStringAllowed(twig_get_attribute($this->env, $this->source, twig_get_attribute($this->env, $this->source, twig_get_attribute($this->env, $this->source, twig_get_attribute($this->env, $this->source, ($context["node"] ?? null), "field_third_banner_image_title", [], "any", false, false, true, 63), "entity", [], "any", false, false, true, 63), "uri", [], "any", false, false, true, 63), "value", [], "any", false, false, true, 63), 63, $this->source)), "html", null, true);
        echo "\" width=\"100%\" height=\"100%\"
         alt=\"";
        // line 64
        echo $this->extensions['Drupal\Core\Template\TwigExtension']->escapeFilter($this->env, $this->sandbox->ensureToStringAllowed(twig_get_attribute($this->env, $this->source, twig_get_attribute($this->env, $this->source, ($context["node"] ?? null), "field_third_banner_image_title", [], "any", false, false, true, 64), "alt", [], "any", false, false, true, 64), 64, $this->source), "html", null, true);
        echo "\" >
    <img class=\"description\" src=\"";
        // line 65
        echo $this->extensions['Drupal\Core\Template\TwigExtension']->escapeFilter($this->env, $this->extensions['Drupal\Core\Template\TwigExtension']->getFileUrl($this->sandbox->ensureToStringAllowed(twig_get_attribute($this->env, $this->source, twig_get_attribute($this->env, $this->source, twig_get_attribute($this->env, $this->source, twig_get_attribute($this->env, $this->source, ($context["node"] ?? null), "field_third_banner_image_text", [], "any", false, false, true, 65), "entity", [], "any", false, false, true, 65), "uri", [], "any", false, false, true, 65), "value", [], "any", false, false, true, 65), 65, $this->source)), "html", null, true);
        echo "\"
         alt=\"";
        // line 66
        echo $this->extensions['Drupal\Core\Template\TwigExtension']->escapeFilter($this->env, $this->sandbox->ensureToStringAllowed(twig_get_attribute($this->env, $this->source, twig_get_attribute($this->env, $this->source, ($context["node"] ?? null), "field_third_banner_image_text", [], "any", false, false, true, 66), "alt", [], "any", false, false, true, 66), 66, $this->source), "html", null, true);
        echo "\" >
    <a class=\"cta-btn\" href=\"";
        // line 67
        echo $this->extensions['Drupal\Core\Template\TwigExtension']->escapeFilter($this->env, $this->sandbox->ensureToStringAllowed(twig_get_attribute($this->env, $this->source, twig_get_attribute($this->env, $this->source, twig_get_attribute($this->env, $this->source, ($context["node"] ?? null), "field_second_banner_button", [], "any", false, false, true, 67), 0, [], "any", false, false, true, 67), "url", [], "any", false, false, true, 67), 67, $this->source), "html", null, true);
        echo "\">
      ";
        // line 68
        echo $this->extensions['Drupal\Core\Template\TwigExtension']->escapeFilter($this->env, $this->sandbox->ensureToStringAllowed(twig_get_attribute($this->env, $this->source, twig_get_attribute($this->env, $this->source, twig_get_attribute($this->env, $this->source, ($context["node"] ?? null), "field_second_banner_button", [], "any", false, false, true, 68), 0, [], "any", false, false, true, 68), "title", [], "any", false, false, true, 68), 68, $this->source), "html", null, true);
        echo "</a>
  </article>
</section>

<section class=\"antiage-banner\">
  <article class=\"first-wrapper\">
    <img src=\"";
        // line 74
        echo $this->extensions['Drupal\Core\Template\TwigExtension']->escapeFilter($this->env, $this->extensions['Drupal\Core\Template\TwigExtension']->getFileUrl($this->sandbox->ensureToStringAllowed(twig_get_attribute($this->env, $this->source, twig_get_attribute($this->env, $this->source, twig_get_attribute($this->env, $this->source, twig_get_attribute($this->env, $this->source, ($context["node"] ?? null), "field_fourth_banner_image_left", [], "any", false, false, true, 74), "entity", [], "any", false, false, true, 74), "uri", [], "any", false, false, true, 74), "value", [], "any", false, false, true, 74), 74, $this->source)), "html", null, true);
        echo "\" width=\"100%\" height=\"100%\"
         alt=\"";
        // line 75
        echo $this->extensions['Drupal\Core\Template\TwigExtension']->escapeFilter($this->env, $this->sandbox->ensureToStringAllowed(twig_get_attribute($this->env, $this->source, twig_get_attribute($this->env, $this->source, ($context["node"] ?? null), "field_fourth_banner_image_left", [], "any", false, false, true, 75), "alt", [], "any", false, false, true, 75), 75, $this->source), "html", null, true);
        echo "\"/>
    <img class=\"antiage-brand\" src=\"";
        // line 76
        echo $this->extensions['Drupal\Core\Template\TwigExtension']->escapeFilter($this->env, $this->extensions['Drupal\Core\Template\TwigExtension']->getFileUrl($this->sandbox->ensureToStringAllowed(twig_get_attribute($this->env, $this->source, twig_get_attribute($this->env, $this->source, twig_get_attribute($this->env, $this->source, twig_get_attribute($this->env, $this->source, ($context["node"] ?? null), "field_fourth_banner_image_centra", [], "any", false, false, true, 76), "entity", [], "any", false, false, true, 76), "uri", [], "any", false, false, true, 76), "value", [], "any", false, false, true, 76), 76, $this->source)), "html", null, true);
        echo "\"
         alt=\"";
        // line 77
        echo $this->extensions['Drupal\Core\Template\TwigExtension']->escapeFilter($this->env, $this->sandbox->ensureToStringAllowed(twig_get_attribute($this->env, $this->source, twig_get_attribute($this->env, $this->source, ($context["node"] ?? null), "field_fourth_banner_image_centra", [], "any", false, false, true, 77), "alt", [], "any", false, false, true, 77), 77, $this->source), "html", null, true);
        echo "\">
  </article>
  <article class=\"second-wrapper\">
    <img class=\"bg-pattern\" src=\"";
        // line 80
        echo $this->extensions['Drupal\Core\Template\TwigExtension']->escapeFilter($this->env, $this->extensions['Drupal\Core\Template\TwigExtension']->getFileUrl($this->sandbox->ensureToStringAllowed(twig_get_attribute($this->env, $this->source, twig_get_attribute($this->env, $this->source, twig_get_attribute($this->env, $this->source, twig_get_attribute($this->env, $this->source, ($context["node"] ?? null), "field_fourth_banner_image_right", [], "any", false, false, true, 80), "entity", [], "any", false, false, true, 80), "uri", [], "any", false, false, true, 80), "value", [], "any", false, false, true, 80), 80, $this->source)), "html", null, true);
        echo "\" width=\"100%\" height=\"100%\"
         alt=\"";
        // line 81
        echo $this->extensions['Drupal\Core\Template\TwigExtension']->escapeFilter($this->env, $this->sandbox->ensureToStringAllowed(twig_get_attribute($this->env, $this->source, twig_get_attribute($this->env, $this->source, ($context["node"] ?? null), "field_fourth_banner_image_right", [], "any", false, false, true, 81), "alt", [], "any", false, false, true, 81), 81, $this->source), "html", null, true);
        echo "\">
    <p class=\"antiage-description\">
      ";
        // line 83
        echo $this->extensions['Drupal\Core\Template\TwigExtension']->escapeFilter($this->env, $this->sandbox->ensureToStringAllowed(twig_get_attribute($this->env, $this->source, twig_get_attribute($this->env, $this->source, ($context["node"] ?? null), "field_fourth_banner_text", [], "any", false, false, true, 83), "value", [], "any", false, false, true, 83), 83, $this->source), "html", null, true);
        echo "
    </p>
    <a class=\"antiage-cta\" href=\"";
        // line 85
        echo $this->extensions['Drupal\Core\Template\TwigExtension']->escapeFilter($this->env, $this->sandbox->ensureToStringAllowed(twig_get_attribute($this->env, $this->source, twig_get_attribute($this->env, $this->source, twig_get_attribute($this->env, $this->source, ($context["node"] ?? null), "field_fourth_banner_button", [], "any", false, false, true, 85), 0, [], "any", false, false, true, 85), "url", [], "any", false, false, true, 85), 85, $this->source), "html", null, true);
        echo "\">
      ";
        // line 86
        echo $this->extensions['Drupal\Core\Template\TwigExtension']->escapeFilter($this->env, $this->sandbox->ensureToStringAllowed(twig_get_attribute($this->env, $this->source, twig_get_attribute($this->env, $this->source, twig_get_attribute($this->env, $this->source, ($context["node"] ?? null), "field_fourth_banner_button", [], "any", false, false, true, 86), 0, [], "any", false, false, true, 86), "title", [], "any", false, false, true, 86), 86, $this->source), "html", null, true);
        echo "</a>
  </article>
</section>

<section class=\"rejuvenece-banner\">

  <picture class=\"first-image\">
    <source srcset=\"";
        // line 93
        echo $this->extensions['Drupal\Core\Template\TwigExtension']->escapeFilter($this->env, $this->extensions['Drupal\Core\Template\TwigExtension']->getFileUrl($this->sandbox->ensureToStringAllowed(twig_get_attribute($this->env, $this->source, twig_get_attribute($this->env, $this->source, twig_get_attribute($this->env, $this->source, twig_get_attribute($this->env, $this->source, ($context["node"] ?? null), "field_fifth_banner_background_de", [], "any", false, false, true, 93), "entity", [], "any", false, false, true, 93), "uri", [], "any", false, false, true, 93), "value", [], "any", false, false, true, 93), 93, $this->source)), "html", null, true);
        echo "\" media=\"(min-width: 1024px)\">
    <img src=\"";
        // line 94
        echo $this->extensions['Drupal\Core\Template\TwigExtension']->escapeFilter($this->env, $this->extensions['Drupal\Core\Template\TwigExtension']->getFileUrl($this->sandbox->ensureToStringAllowed(twig_get_attribute($this->env, $this->source, twig_get_attribute($this->env, $this->source, twig_get_attribute($this->env, $this->source, twig_get_attribute($this->env, $this->source, ($context["node"] ?? null), "field_fifth_banner_background_mo", [], "any", false, false, true, 94), "entity", [], "any", false, false, true, 94), "uri", [], "any", false, false, true, 94), "value", [], "any", false, false, true, 94), 94, $this->source)), "html", null, true);
        echo "\" width=\"100%\" height=\"100%\"
         alt=\"";
        // line 95
        echo $this->extensions['Drupal\Core\Template\TwigExtension']->escapeFilter($this->env, $this->sandbox->ensureToStringAllowed(twig_get_attribute($this->env, $this->source, twig_get_attribute($this->env, $this->source, ($context["node"] ?? null), "field_fifth_banner_background_de", [], "any", false, false, true, 95), "alt", [], "any", false, false, true, 95), 95, $this->source), "html", null, true);
        echo "\"/>
  </picture>

  <picture class=\"second-image\">
    <source srcset=\"";
        // line 99
        echo $this->extensions['Drupal\Core\Template\TwigExtension']->escapeFilter($this->env, $this->extensions['Drupal\Core\Template\TwigExtension']->getFileUrl($this->sandbox->ensureToStringAllowed(twig_get_attribute($this->env, $this->source, twig_get_attribute($this->env, $this->source, twig_get_attribute($this->env, $this->source, twig_get_attribute($this->env, $this->source, ($context["node"] ?? null), "field_fifth_banner_text_desktop_", [], "any", false, false, true, 99), "entity", [], "any", false, false, true, 99), "uri", [], "any", false, false, true, 99), "value", [], "any", false, false, true, 99), 99, $this->source)), "html", null, true);
        echo "\" media=\"(min-width: 1024px)\">
    <img src=\"";
        // line 100
        echo $this->extensions['Drupal\Core\Template\TwigExtension']->escapeFilter($this->env, $this->extensions['Drupal\Core\Template\TwigExtension']->getFileUrl($this->sandbox->ensureToStringAllowed(twig_get_attribute($this->env, $this->source, twig_get_attribute($this->env, $this->source, twig_get_attribute($this->env, $this->source, twig_get_attribute($this->env, $this->source, ($context["node"] ?? null), "field_fifth_banner_text_mobile_i", [], "any", false, false, true, 100), "entity", [], "any", false, false, true, 100), "uri", [], "any", false, false, true, 100), "value", [], "any", false, false, true, 100), 100, $this->source)), "html", null, true);
        echo "\" width=\"100%\" height=\"100%\"
         alt=\"";
        // line 101
        echo $this->extensions['Drupal\Core\Template\TwigExtension']->escapeFilter($this->env, $this->sandbox->ensureToStringAllowed(twig_get_attribute($this->env, $this->source, twig_get_attribute($this->env, $this->source, ($context["node"] ?? null), "field_fifth_banner_text_desktop_", [], "any", false, false, true, 101), "alt", [], "any", false, false, true, 101), 101, $this->source), "html", null, true);
        echo "\"/>
  </picture>

</section>

<section class=\"reviews\">
  <div class=\"splide\" aria-label=\"slider reviews\">
    <div class=\"splide__track\">
      <ul class=\"splide__list\">
        ";
        // line 110
        $context['_parent'] = $context;
        $context['_seq'] = twig_ensure_traversable(twig_get_attribute($this->env, $this->source, ($context["node"] ?? null), "field_slider_customers", [], "any", false, false, true, 110));
        foreach ($context['_seq'] as $context["_key"] => $context["item"]) {
            // line 111
            echo "          <li class=\"splide__slide\">
            <h3>";
            // line 112
            echo $this->extensions['Drupal\Core\Template\TwigExtension']->escapeFilter($this->env, $this->sandbox->ensureToStringAllowed(twig_get_attribute($this->env, $this->source, twig_get_attribute($this->env, $this->source, twig_get_attribute($this->env, $this->source, $context["item"], "entity", [], "any", false, false, true, 112), "field_title", [], "any", false, false, true, 112), "value", [], "any", false, false, true, 112), 112, $this->source), "html", null, true);
            echo "</h3>
            <hr>
            <p>
              ";
            // line 115
            echo $this->extensions['Drupal\Core\Template\TwigExtension']->escapeFilter($this->env, $this->sandbox->ensureToStringAllowed(twig_get_attribute($this->env, $this->source, twig_get_attribute($this->env, $this->source, twig_get_attribute($this->env, $this->source, $context["item"], "entity", [], "any", false, false, true, 115), "field_description", [], "any", false, false, true, 115), "value", [], "any", false, false, true, 115), 115, $this->source), "html", null, true);
            echo "
            </p>
          </li>
        ";
        }
        $_parent = $context['_parent'];
        unset($context['_seq'], $context['_iterated'], $context['_key'], $context['item'], $context['_parent'], $context['loop']);
        $context = array_intersect_key($context, $_parent) + $_parent;
        // line 119
        echo "      </ul>
    </div>
  </div>
</section>

<!-- INSERTAR AQUI EL MAPA -->
<!-- 
    <section class=\"map\">

    </section> -->

<section class=\"form\">
  <form class=\"form-contact\">
    <div class=\"form-wrapper\">
      <label for=\"name\">Nombre*</label>
      <input type=\"text\" name=\"name\" placeholder=\"Ingresa tu nombre\">
    </div>
    <div class=\"form-wrapper\">
      <label for=\"address\">Direccion</label>
      <input type=\"text\" name=\"address\" placeholder=\"Ingresa tu dirección\">
    </div>

    <div class=\"form-wrapper form-wrapper__contact\">
      <label for=\"name\">Email*</label>
      <input type=\"email\" name=\"email\" placeholder=\"Ingresa tu email\">
    </div>

    <div class=\"form-wrapper form-wrapper__contact\">
      <label for=\"phone\">Teléfono</label>
      <input type=\"text\" name=\"phone\" placeholder=\"Ingresa tu número de telefono\">
    </div>

    <div class=\"form-wrapper\">
      <label for=\"subject\">Asunto</label>
      <input type=\"text\" name=\"subject\" placeholder=\"Ingresa el asunto\">
    </div>

    <div class=\"form-wrapper\">
      <label for=\"message\">Mensaje</label>
      <textarea name=\"message\"cols=\"30\" rows=\"10\" placeholder=\"Escribe tu mensaje\"></textarea>
    </div>

    <button class=\"form-cta\" type=\"submit\">ENVIAR</button>
  </form>
</section>

<footer class=\"footer\" id=\"form\">
  <section class=\"social\">
    ";
        // line 167
        $context['_parent'] = $context;
        $context['_seq'] = twig_ensure_traversable(twig_get_attribute($this->env, $this->source, ($context["node"] ?? null), "field_social", [], "any", false, false, true, 167));
        foreach ($context['_seq'] as $context["_key"] => $context["item"]) {
            // line 168
            echo "      <a href=\"";
            echo $this->extensions['Drupal\Core\Template\TwigExtension']->escapeFilter($this->env, $this->sandbox->ensureToStringAllowed(twig_get_attribute($this->env, $this->source, twig_get_attribute($this->env, $this->source, twig_get_attribute($this->env, $this->source, $context["item"], "entity", [], "any", false, false, true, 168), "field_link", [], "any", false, false, true, 168), "value", [], "any", false, false, true, 168), 168, $this->source), "html", null, true);
            echo "\">
        <img src=\"";
            // line 169
            echo $this->extensions['Drupal\Core\Template\TwigExtension']->escapeFilter($this->env, $this->extensions['Drupal\Core\Template\TwigExtension']->getFileUrl($this->sandbox->ensureToStringAllowed(twig_get_attribute($this->env, $this->source, twig_get_attribute($this->env, $this->source, twig_get_attribute($this->env, $this->source, twig_get_attribute($this->env, $this->source, twig_get_attribute($this->env, $this->source, $context["item"], "entity", [], "any", false, false, true, 169), "field_logo", [], "any", false, false, true, 169), "entity", [], "any", false, false, true, 169), "uri", [], "any", false, false, true, 169), "value", [], "any", false, false, true, 169), 169, $this->source)), "html", null, true);
            echo "\" alt=\"";
            echo $this->extensions['Drupal\Core\Template\TwigExtension']->escapeFilter($this->env, $this->sandbox->ensureToStringAllowed(twig_get_attribute($this->env, $this->source, twig_get_attribute($this->env, $this->source, twig_get_attribute($this->env, $this->source, $context["item"], "entity", [], "any", false, false, true, 169), "field_logo", [], "any", false, false, true, 169), "alt", [], "any", false, false, true, 169), 169, $this->source), "html", null, true);
            echo "\">
      </a>
    ";
        }
        $_parent = $context['_parent'];
        unset($context['_seq'], $context['_iterated'], $context['_key'], $context['item'], $context['_parent'], $context['loop']);
        $context = array_intersect_key($context, $_parent) + $_parent;
        // line 172
        echo "  </section>
  <img class=\"logo\" src=\"";
        // line 173
        echo $this->extensions['Drupal\Core\Template\TwigExtension']->escapeFilter($this->env, $this->extensions['Drupal\Core\Template\TwigExtension']->getFileUrl($this->sandbox->ensureToStringAllowed(twig_get_attribute($this->env, $this->source, twig_get_attribute($this->env, $this->source, twig_get_attribute($this->env, $this->source, twig_get_attribute($this->env, $this->source, ($context["node"] ?? null), "field_logo", [], "any", false, false, true, 173), "entity", [], "any", false, false, true, 173), "uri", [], "any", false, false, true, 173), "value", [], "any", false, false, true, 173), 173, $this->source)), "html", null, true);
        echo "\"
       alt=\"";
        // line 174
        echo $this->extensions['Drupal\Core\Template\TwigExtension']->escapeFilter($this->env, $this->sandbox->ensureToStringAllowed(twig_get_attribute($this->env, $this->source, twig_get_attribute($this->env, $this->source, ($context["node"] ?? null), "field_logo", [], "any", false, false, true, 174), "alt", [], "any", false, false, true, 174), 174, $this->source), "html", null, true);
        echo "\">
</footer>



";
    }

    public function getTemplateName()
    {
        return "themes/custom/theme_dr_mario/templates/page--node--2.html.twig";
    }

    public function isTraitable()
    {
        return false;
    }

    public function getDebugInfo()
    {
        return array (  388 => 174,  384 => 173,  381 => 172,  370 => 169,  365 => 168,  361 => 167,  311 => 119,  301 => 115,  295 => 112,  292 => 111,  288 => 110,  276 => 101,  272 => 100,  268 => 99,  261 => 95,  257 => 94,  253 => 93,  243 => 86,  239 => 85,  234 => 83,  229 => 81,  225 => 80,  219 => 77,  215 => 76,  211 => 75,  207 => 74,  198 => 68,  194 => 67,  190 => 66,  186 => 65,  182 => 64,  178 => 63,  174 => 62,  170 => 61,  165 => 59,  161 => 58,  156 => 56,  152 => 55,  140 => 48,  136 => 47,  131 => 45,  127 => 44,  123 => 43,  113 => 36,  102 => 30,  98 => 29,  92 => 26,  88 => 25,  84 => 24,  76 => 18,  65 => 16,  61 => 15,  49 => 6,  45 => 5,  39 => 1,);
    }

    public function getSourceContext()
    {
        return new Source("", "themes/custom/theme_dr_mario/templates/page--node--2.html.twig", "/var/www/html/web/themes/custom/theme_dr_mario/templates/page--node--2.html.twig");
    }
    
    public function checkSecurity()
    {
        static $tags = array("for" => 15);
        static $filters = array("escape" => 5, "raw" => 29);
        static $functions = array("file_url" => 5);

        try {
            $this->sandbox->checkSecurity(
                ['for'],
                ['escape', 'raw'],
                ['file_url']
            );
        } catch (SecurityError $e) {
            $e->setSourceContext($this->source);

            if ($e instanceof SecurityNotAllowedTagError && isset($tags[$e->getTagName()])) {
                $e->setTemplateLine($tags[$e->getTagName()]);
            } elseif ($e instanceof SecurityNotAllowedFilterError && isset($filters[$e->getFilterName()])) {
                $e->setTemplateLine($filters[$e->getFilterName()]);
            } elseif ($e instanceof SecurityNotAllowedFunctionError && isset($functions[$e->getFunctionName()])) {
                $e->setTemplateLine($functions[$e->getFunctionName()]);
            }

            throw $e;
        }

    }
}
